Domains: War, Thunder, Heroism, Valor

Personality: Boisterous, stubborn, courageous—a god of action and brotherhood.

Symbols: A hammer striking a mountain.

Worshippers: Warriors, blacksmiths, storm-priests.

Rivalries: Kharzun the Dread Serpent, rivals Aeltherion philosophically.

"Steel sings loudest when thunder calls."
