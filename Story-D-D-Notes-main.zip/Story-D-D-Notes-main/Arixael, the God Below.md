Domains: Shadows, Secrets, Forbidden Lore, Transformation

Personality: Tempting, suave, half-mad; offers power at a price.

Symbols: A mask with no face, surrounded by nine runes.

Worshippers: Alchemists, spies, changelings, lost souls.

Rivalries: Virelya, Aeltherion.

"Truth lies not in light, but in what it leaves hidden."