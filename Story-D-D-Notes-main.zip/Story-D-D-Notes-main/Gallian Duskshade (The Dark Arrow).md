Dark Elf, Tall, slender, 6 '1, dark blue eyes, skilled in archery, dual wielding blades, tracking, athletics, mathematics. Destined to sit on the council of dark elves, and lead his house/clan. 
