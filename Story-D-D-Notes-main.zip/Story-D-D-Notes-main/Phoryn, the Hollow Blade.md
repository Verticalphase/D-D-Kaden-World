[[Lesser Gods]] 
**Domains:** War, Shadows, Assassination, Silence  

**Personality:** Cold, methodical, without mercy.  

**Symbol:** A sword with no hilt, vanishing into darkness.  

**Worshippers:** Assassins, spies, soldiers-for-hire.  

**Rivalries:** Thalorien (for honorable combat).  

**Quote:** “The perfect strike is never seen, never heard.”

