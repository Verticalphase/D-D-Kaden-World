[[Lesser Gods]] 
**Domains:** Stars, Navigation, Destiny, Exploration  

**Personality:** Curious, serene, speaks in riddles and constellations.  

**Symbol:** A silver loom weaving a net of stars.  

**Worshippers:** Sailors, stargazers, explorers.  

**Rivalries:** Kharzun (who thrives in the starless dark).  

**Quote:** “Every journey is written among the stars.”

