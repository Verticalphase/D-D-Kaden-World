**Zephyraxia - 2,129 miles [[Zephyraxia (Dragonborn Kingdom)]]

**Eryssandor** - **1,173 miles** [[Eryssandor (Human Kingdom)]]

**Ssarth' Ka** - **1,088 miles**  [[Ssarth’Ka (Lizard Folk Kingdom)]]

**Barag-Thol - 3,939 miles [[Barag-Thol (Dwarven Kingdom)]]

**Targannon - 1,397 miles [[Targannon (Human Kingdom)]]

**Aerendir - 1,050 miles [[Aerendir (High Elves Kingdom)]]

**Soltheris Imperium - 1,800 miles [[Soltheris Imperium (Human Kingdom)]]

**Aetherdralis - 1,166 miles [[Aetherdralis (Human Kingdom)]]

**Thruk-Mor Dominion - 1,667 miles [[Thruk-Mor Dominion (Orc Kingdom)]]

**Ironvale - 1,456 miles [[Ironvale (Human Kingdom)]]

**Noctyriel - 1,498 miles [[Noctyriel (Dark Elves Kingdom)]] 

**Valwynd - 3,245 miles [[Valwynd Empire (Human Kingdom)]]

**Thalyssar - 760 miles [[Thalyssar (Blood Elves Kingdom)]] 










