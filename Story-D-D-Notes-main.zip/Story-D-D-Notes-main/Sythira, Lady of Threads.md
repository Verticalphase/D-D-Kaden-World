Domains: Fate, Time, Mercy, Death (peaceful)

Personality: Calm, maternal, eerie in her patience. Knows the hour of every soul’s end.

Symbols: A spinning wheel with a broken hourglass.

Worshippers: Monks, seers, grave-keepers, midwives.

Rivalries: Thalorien (who defies fate), Nythraxis.

"Every thread frays. Every soul returns."