# Current Age 
[[The Veilbound Cycle (1532-1849) Present]]

# Characters 
[[Kecrine Drakos (Dawnstar)]]

Celestial, orphaned, white hair, dark purple eyes, glimmering skin, 6ft brawn gifted in skills of any kind, destined for greatness and extinction.

---

[[Jerred Drakos (The Speared Sentinel)]]

Human, brown hair, 5’ 11 blue eyes, smaller frame, built, skilled in charisma, happy, skilled in the spear and shield, skilled in tactics. Descendant of royalty, destined to be king, peacemaker. 

[[Marry Fairweather (The Dreamer)]]

Human, Blonde hair, average build, 5’ 4 hazel eyes skilled in martial arts/hand-to-hand combat, artist, kind, destined to see parts of the future, dreams become reality.

[[Darren Wiseclaw (The Navigator)]]  
Human, noble, ginger hair, brawn build, blue eyes, freckles, 6 ft, destined to be lord of a great house, wants to travel/explore away from duties, skilled in mapmaking and navigation. 

[[Haela Rainweaver (The Elven Storm)]] 
Half Human-Half Dark Elf, Brown eyes, darkened freckles, 5 ‘1 ft, small, slender, black hair, straight forward talking, skilled in speed, dual-wielding daggers, can bend/manipulate water, rain enhances her senses, and skills, family bloodline gift, destined to enhance her abilities for betterment of her people.

[[Gallian Duskshade (The Dark Arrow)]] 
Dark Elf, Tall, slender, 6 '1, dark blue eyes, darkened freckles, skilled in archery, dual wielding blades, tracking, athletics, mathematics. Destined to sit on the council of dark elves, and lead his house/clan. 

[[Corgrim Greenpine (Defender of the Wild)]] 
Wood Elf green eyes, average build, smaller frame, 5 '9, dreaded hair, skilled in tracking, green thumb, shapeshifting, talking to animals, plant manipulation, earth bending. Father abandoned mother and child, destined to set path of discovery, protect forests and lands from other beings meaning to destroy them.

[[Merros Kelpos (The Living Engine)]] 
Gnome, brown eyes, brown hair, skinny for a gnome, 3’5 ft tall, glasses, likes bio-engineer, tinkerer, engineer, inventionist, Was raised in the engineer’s guild, left to create his own destiny, and adventure.

[[Davon Drakonov (The Night Blades)]] 
Human, brown eyes, brown hair, 5’ 10 ft tall, has a different accent compared to locals, straightforward, athletic frame, flexible, great at climbing, animals, and drinking, grew up as a hunter in the woods with family, wanted to leave and see the world. 

[[Sam Ashen (The Night Blades)]] 
Human, brown hair, brown eyes, 6 ft tall, athletic and bigger frame, flexible, has a lot of charisma, good looking, great at climbing, one handed weapons. Grew up as a baker’s son, went to the city for education, got tossed up with a bad group, left for a new start and adventure. 

[[Corbin Blackrose (Blood-Shade)]] 
Blood Elf, Tall, 6 ‘1 ft, pale white skin, yellow eyes, silver hair, skinny but fit, very intelligent, good at history, good charisma, stuck-up, royal destined to be leader of all Blood-Elves, traveling to accumulate knowledge, and search for resources to better his kingdom and people. 

[[WulfBeorn (Wulf) (Shield’s Bane)]] 
Human, red hair, green eyes, 6 ‘2 ft tall, very fit, defined form, berserker fighter, skilled in dual wielding blades (axes), great fighter, very loyal, headstrong, seeking adventure, and honor his legacy for his family, an honorable life and death. 

[[Nadaar Daar (The Dragon’s Calamity)]] 
Dragonborn, blue scales, green eyes, no horns, outcast, 6 ‘2 ft tall, fit/athletic frame, wizard/mage, very kind, respectful, powerful, grew up in a war-torn impoverished land, seeking better life, opportunity given to join mage guild, on journey to improve his magical capabilities for higher status of guild. 

[[Karii (The Divine’s Skinchanger)]] 
Changeling, 5 ‘4 ft tall, pale skin, silver hair, red eyes, skinny/fit frame, shy, weird fascination with things/people that are different than ordinary, fast, refrains from hurting as much as possible, carefree, grew up with older sister living from place to place, sister taught her ways in healing, and cleric trainings, mistreated by public for race, and looks, older sister died protecting her, life on the run to find a home with people who love her for herself.

[[Korr ( The Mighty Born)]] 
Goliath, 6 ‘9 ft tall, greyish skin, strongman build, less intelligent than average, bald, loves fighting, happy soul, cares for the people he loves, very powerful. Can’t read or write well, grew up as a kingdom’s gladiator, earned freedom through killing, wants to live life on his own terms, travelling, eating, fighting is what he yearns for.
