**Eryssandor (Human Kingdom)- “The magically blessed land”**  [[The Age of Splendor (311-926 A.D.- The High Empire)]]  [[Kingdoms]] 

- The Kingdom’s wealth comes from their fertile lands like farmlands, plantations which are helped through magical intervention from their magic users.
    
- Mandates claiming rulers must be magically inclined and chosen by the gods or spirits of the land.
    
- Erys: Come from Erysium (evoking Elysium), giving a sense of divine favor, blessed land, or beauty.
    
- sand: A middle root that feels earthy, symbolizes land, soil, foundation, and endurance.
    
- or/dor: Common in old high fantasy meaning realm, land, or domain. 
    