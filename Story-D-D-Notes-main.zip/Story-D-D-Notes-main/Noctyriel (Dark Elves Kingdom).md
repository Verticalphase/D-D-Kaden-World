**Noctyriel (Dark Elves Kingdom)- “Realm of the Nights Song”**  [[The Creation Era - (Unknown start)]] [[Kingdoms]]

- A realm steeped in mysticism, shadow magic, and nocturnal worship.
    
- The kingdom reveres the night not as darkness to hide in, but as a sacred veil-their protector and patron.
    
- A society of subtle politics, veiled power, and dangerous beauty. Many things within the lands are graceful, but deadly. 
    
- Noct: From Latin nox/noctis, meaning “night”. This root implies darkness, secrecy, and the power of the unseen.
    
- yriel: A melodic, elven sounding suffix. Means “crown, maiden, song, or realm”, in an ancient tongue, but always with a lyrical, almost ethereal quality. 