[[Lesser Gods]] 
**Domains:** Mountains, Endurance, Labor, Craft  

**Personality:** Stoic, stubborn, slow to anger but unyielding in judgment.  

**Symbol:** A chiseled anvil beneath a mountain peak.  

**Worshippers:** Miners, masons, stonecutters, dwarves.  

**Rivalries:** Lorrakai (he despises her erosion of his mountains).  

**Quote:** “What is built to last is built to bear the ages.”
