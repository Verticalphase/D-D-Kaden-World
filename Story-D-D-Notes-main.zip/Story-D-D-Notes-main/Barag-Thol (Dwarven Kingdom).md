**Barag-Thol (Dwarven Kingdom)- “Stronghold of the Anvil”**  [[The Age of Splendor (311-926 A.D.- The High Empire)]]  [[Kingdoms]]  

- The name is the title of their greatest fortress, with the kingdom taking its name from the legendary hall.

- A culture rooted in unyielding defense, craftsmanship, and stonework.

- Barag: Is an old Dwarvish root, meaning “fortress, stronghold, or citadel”.

- Thol: Short, blunt, and weighty. Meaning “stone, mountain, or anvil”.


