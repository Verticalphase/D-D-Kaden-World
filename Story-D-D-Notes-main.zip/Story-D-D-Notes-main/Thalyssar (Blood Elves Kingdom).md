**Thalyssar (Blood Elves Kingdom)- “Throne of the Crimson Depths”** [[The Creation Era - (Unknown start)]]  [[Kingdoms]]

- An ancient, decadent realm, once a beacon of magical and cultural brilliance, now marked by hidden sacrifice, obsession, and corruption.
    
- The kingdom was founded near the sea, as the Blood Elves draw power from the ocean, and its hidden materials. 
    
- The kingdom is known for their refined cruelty, a society that values art and beauty, but does not shy from blood magic, dark rituals, and ruthless politics. 
    
- Thal: Often tied to roots meaning “sea or depths” in fantasy. It suggests vastness, old magic, and something ancient and unending.
    
- yssar: Carries a sharp, almost serpentine bite. It implies “crown, dominion, or noble house,” but with an undertone of power or control, even a hint of menace.**

