Domains: Nothingness, Madness, Forbidden Knowledge, Endings

Personality: Silent, ever-present, felt in the space between thoughts.

Symbols: A ring of black teeth surrounding a void.

Worshippers: Cultists, doomsayers, corrupted mages.

Rivalries: All gods, especially Aeltherion and Thalorien.

"In the end, all returns to Nythraxis."