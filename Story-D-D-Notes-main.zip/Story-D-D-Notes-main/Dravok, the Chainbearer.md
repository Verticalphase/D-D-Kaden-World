[[Lesser Gods]] 
**Domains:** Contracts, Law, Binding Oaths, Retribution  

**Personality:** Stern, uncompromising, sees promises as sacred chains.  

**Symbol:** Interlocking silver chains forming a circle.  

**Worshippers:** Judges, diplomats, mercenaries, bounty hunters.  

**Rivalries:** Elaren (for chaos and rebellion).  

**Quote:** “Freedom is a promise kept, not a promise broken.”
