**Thruk-Mor Dominion (Orc Kingdom)- “The Dominion of Blood and Power”**  [[The Veilbound Cycle (1532-1849) Present]]  [[Kingdoms]]  

- Forged in war and conquest- a realm where strength is law and weakness is scorned.
    
- Over the years they grew from isolated tribes, into a unified tribe, eventually growing larger and more disciplined. Transitioning from raiders to empire-builders. 
    
- Feared for their power and aggression, but respected for their strict order and martial honor.
    
- Thruk: Harsh and guttural, evokes brutal strength, breaking, crushing. In Orc tongue it means “to smash, to conquer, or wrath”.
    
- Mor: Short, deep, and weighty. In many fantasy tongues, mor implies darkness, blood, or great power. 
    
- Dominion: Not just a kingdom, but an expanding rule, they claim and enforce power over others. 