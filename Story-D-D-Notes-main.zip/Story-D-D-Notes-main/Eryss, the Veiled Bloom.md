[[Lesser Gods]] 
**Domains:** Beauty, Illusion, Desire, Transformation  

**Personality:** Seductive, enigmatic, thrives on change and reinvention. 

**Symbol:** A flower half real, half shadow.  

**Worshippers:** Courtesans, actors, illusionists.  

**Rivalries:** Myrris (for distorting truth).  

**Quote:** “Beauty is not in what you see—it’s in what you believe you see.”

