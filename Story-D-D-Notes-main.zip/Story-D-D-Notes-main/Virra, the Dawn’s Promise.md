[[Lesser Gods]] 
**Domains:** Light, Hope, Renewal, Healing  

**Personality:** Compassionate, idealistic, relentlessly optimistic.  

**Symbol:** A sunrise breaking through clouds.  

**Worshippers:** Healers, farmers, refugees.  

**Rivalries:** Arixael (for spreading shadows and lies).  

**Quote:** “Every night ends. Every shadow flees.”
