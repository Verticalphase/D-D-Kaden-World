- The creation of the planet and gods by primordial beings
  
The Dawning Age (0-311 AD,( “The First Light”) A.D= After Dawn

Theme- The rise of civilizations, after the end of primordial chaos and creation.

Tone- Mythic and Hopeful

Important Events-

- The gods walk among mortals
    
- The first kingdoms are founded/created
    
- Magic is gifted to the world
    
- First peace pact between natural beings ( Elves, druids, elementals etc.) and humans and other beings signed in a sacred grove that glows with moonlight.
    
- Ended by the Sundering of the skies- a divine betrayal and the disappearance of the gods.
    

Heroes, Artifacts, Creatures:

Aralon the Flame-born- a child born in dragon fire who led tribes to unite against the storm giants.

Seren Elyria- Elven archdruid who tamed the World root Tree and created the first circle of harmony. 

The Crown of Morninglight- forged by solarmasters, worn by the first king blessed by the gods.

Skystriders- Gigantic winged elk ridden by early skyward tribes.

The First Hydra- Born in a primordial marsh, said to be the spawn of the world’s chaotic heart. 
