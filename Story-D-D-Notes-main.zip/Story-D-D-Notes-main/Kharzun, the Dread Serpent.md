Domains: Beasts, Darkness, Poison, Predation

Personality: Primal, brutal, survival-driven—respects strength.

Symbols: Twin fangs coiled around a black sun.

Worshippers: Beastmasters, assassins, tribal warlords.

Rivalries: Thalorien, Sythira.

"To hunt is to live. To be hunted is to perish."
