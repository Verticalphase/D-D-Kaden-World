# Summary
Celestial, orphaned, white hair, dark purple eyes, glimmering skin, 6ft brawn gifted in skills of any kind, destined for greatness and extinction.