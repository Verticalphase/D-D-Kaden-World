Theme- Rebuilding from the ashes.

                                Tone- Struggling but rising.

                                 Important Events-

- New kingdoms rise, alliances begin.
    
- Religions splinter, except for one that grows exponentially throughout the realm (Order from Flame, Flame God).
    
- The Reclaiming Wars- Mortal races fight to restore ruined regions from monsters and warlords.
    
- The Trial of Thirteen Crowns- Rival kingdoms to the empire undergo a trial through god-ordained petitions. 
    
-  Ended by the aftermath of the Thirteen Infernos- A rebellion of kingdoms towards the throne, involving dragonfire and death, only lasted 31 days. Most dragons that were under kingdom rule were wiped out. Many kingdoms of mortal races were weakened heavily through this conflict.
    

Heroes, Artifacts, Creatures:

Lady Miren Dawnbreaker- Wielded the reforged Heartstone Blade to unite the eastern baronies, however near the end of the Thirteen Infernos war, the barony lords betrayed her and took the legendary blade. 

The Flame-Soaked Crown- A crown forged from the pieces of other crowns during the Thirteen Infernos War, soaked with blood that ignites flame, by the empire’s sorcerers. 
