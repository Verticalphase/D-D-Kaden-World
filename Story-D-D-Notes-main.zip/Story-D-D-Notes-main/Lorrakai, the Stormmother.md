Domains: Sea, Weather, Nature, Rebirth

Personality: Wild, emotional, nurturing but unpredictable.

Symbols: A wave crashing through an open eye.

Worshippers: Sailors, druids, coastal cities, wildfolk.

Rivalries: Aeltherion (for damming rivers and walls), Azrakar.

"The tide bows to no throne."
