[[Lesser Gods]] 
**Domains:** Fire, Smithing, Invention, Endurance  

**Personality:** Gruff but patient; views hardship as a forge for the soul.  

**Symbol:** An anvil with flames rising from it.  

**Worshippers:** Blacksmiths, armorers, engineers.  

**Rivalries:** Azrakar (for destruction without purpose).  

**Quote:** “Only through heat is steel made strong.”
