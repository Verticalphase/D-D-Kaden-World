**Zephyraxia (Dragonborn)- “Realm of the Windfang”  [[The Reforging Age (1021-1532 A.D.- Rise from Ruin)]]  [[Kingdoms]] 

- Famed for their airships and trade built around the sky, using the sky to dominate trade and exploration.

- Zephyr: From Greek origin meaning “gentle breeze”. It suggests air movement, tying the kingdom to sky worship.

- rax: A common draconic-sounding root, often implying dragon, fang, or might. It adds strength and power to the name.

- ia: A suffix often used for lands, realms, or nations making it feel like a formal kingdom name.

 ### **Skyclad Monarchy (High Skythrone)**

- **Structure:** A hereditary monarch known as the _Skyfang Sovereign_ rules from the capital citadel.

- **Power Base:** The ruler controls the airship armada and grants sky routes to noble houses.

- **Why it fits:** In a post-ruin era, strong centralized leadership would rebuild fleets and enforce dominance.

- **Flavor:** Court intrigue among airship captains and noble dragonborn families is constant.
