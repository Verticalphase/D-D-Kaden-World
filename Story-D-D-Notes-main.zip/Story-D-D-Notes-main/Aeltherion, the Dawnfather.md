Domains: Sun, Creation, Law, Order

Personality: Just, proud, unwavering—believes in civilization above all.

Symbols: A radiant sunburst crowned with twelve stars.

Worshippers: Emperors, judges, paladins, city-builders.

Rivalries: Nythraxis, Lorrakai the Stormmother.
  
"All light has its source. All laws, their beginning."