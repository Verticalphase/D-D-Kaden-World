**Targannon (Human Kingdom)- “Realm of the High Hammer”**  [[The Reforging Age (1021-1532 A.D.- Rise from Ruin)]]  [[Kingdoms]] 

- Aggressive, expansionist, military renowned kingdom, the name was earned on the battlefields.
    
- Dynasty/bloodline forged the kingdom through conquest, “Path of the Hammer” Ideology.
    
- Has the weight of imperial ambition- a name that sounds like it commands respect and fear from its neighbors.
    
- Tar: Often refers to “high, great, or mighty” in fantasy.
    
- gann: A strong, heavy root, meaning “hammer, might, war, endurance”.
    
- on: A classic ending for realms or dynasties, meaning “land of realm, or domain”
    
