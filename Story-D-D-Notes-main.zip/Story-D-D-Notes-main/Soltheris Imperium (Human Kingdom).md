**Soltheris Imperium (Human Kingdom)- “Dominion of the Solar Throne”**  [[The Reforging Age (1021-1532 A.D.- Rise from Ruin)]]  [[Kingdoms]] 

- Their tapestry, art, carvings, and imagery implies their rulers have a divine right to rule, seeing their emperor/empress as chosen by the Flame God.
    
- A centralized, proud, and expansionist power, seeing themselves as the “savior/light” of civilization spreading over to “lesser lands”.
    
- Strong religious state where sun/flame temples, solar festivals, and light rituals are integral to law and culture.
    
- The name Imperium suggests they think of themselves not as a kingdom, but as a world-spanning empire, even if their borders don’t fully match their ambitions.
    
- Sol: From Latin sol, meaning “sun”. Meaning light, radiance, warmth, and divine authority.
    
- theris: An elegant, slightly sharp ending, meaning “crown, rule, and chosen/ordained”. In a poetic sense, it implies “those of the sun” or the “sun’s will”.
    
- Imperium: Directly means “empire” in Latin, implying not just a kingdom but a sprawling dominion, with colonies, vassal states, and divine authority.   
    