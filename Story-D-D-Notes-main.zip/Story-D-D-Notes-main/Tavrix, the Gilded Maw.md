[[Lesser Gods]] 
**Domains:** Trade, Wealth, Luck, Greed  

**Personality:** Charming, cunning, always seeking a better deal.  

**Symbol:** A coin bitten in half.  

**Worshippers:** Merchants, gamblers, thieves.  

**Rivalries:** Dravok (for cheating contracts).  

**Quote:** “Fortune favors the bold—and the bold favor themselves.”

