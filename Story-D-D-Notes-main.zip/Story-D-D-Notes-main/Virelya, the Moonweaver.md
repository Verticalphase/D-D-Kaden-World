Domains: Moon, Magic, Secrets, Dreams

Personality: Serene but cryptic, a silent observer who speaks through dreams.

Symbols: Crescent moon entwined with a silver thread.

Worshippers: Mages, dreamwalkers, oracles, mystics.

Rivalries: Azrakar the Flame-Tyrant.

"The moon sees what the sun dares not."