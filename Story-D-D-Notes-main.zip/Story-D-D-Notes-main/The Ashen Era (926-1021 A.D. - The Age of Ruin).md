 Theme- Ruin, plague, and chaos

                        Tone- Dark and desperate

                         Important Events- 

- The Magefall Cataclysm- A cabal of archmages attempts to merge the material and ethereal planes- half the empire is erased.
    
- The Hollow Harvest- Crops die, skies darken, and plague spreads through corrupted magic. 
    
- Rise of the Bone Courts- Necromancers become more common, and claim dominion of many areas throughout the realm, creating undead armies.
    
- Cities fall to warlords, beast kings, or famine.
    
- The Order of Flame is founded to preserve knowledge, while also becoming a new order, they also create a new religion that worships a fire god that promises to bring the dawn, and burn their enemies. 
    
- Ended by the crowning of a young queen Elaria that unites the realm under one banner and religion, daughter of the legendary heroes, Estaria the Blind a Ranger that assassinated the four necromancer kings with her cursed arrows that blinded her in the end. Brother Kaen of the Ember Chain (Name of the flame order before renaming themselves). A monk who walked through a burning ritual and returned with divine flames in his veins, both were lovers. 
    

Heroes, Artifacts, Creatures:

The Ashen Bell- A relic that can silence all magic in a region for a day.

Plagueborn- Babies of any race that were cursed by corrupted magic would turn into plague-like corrupted beings hell bent on evil doing.

Hollow Drakes- Dragons that would be corrupted by plague magic would turn into undead destructive creatures killing anything and anyone.
