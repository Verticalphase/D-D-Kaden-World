[[Lesser Gods]] 
**Domains:** Knowledge, Memory, History, Truth  

**Personality:** Quiet, meticulous, seeks to preserve every story.  

**Symbol:** A silver quill dripping ink into a pool.  

**Worshippers:** Scribes, historians, librarians.  

**Rivalries:** Elaren (who distorts history with chaos).  

**Quote:** “What is forgotten is lost. What is written is eternal.”
