**Ssarth’Ka (Lizard Folk Kingdom)- “Scaled Lands”**  [[The Age of Splendor (311-926 A.D.- The High Empire)]]  [[Kingdoms]] 

- A culture that values primordial strength, and reveres a great serpent god.
    
- Ancestral grounds, a place they claim fiercely and defend without mercy.
    
- Swamplands, jungles filled with ancient ruins.
    
- Ssarth: Harsh and serpentine, means scaled, fanged, serpent in their tongue. Double “S” emphasizes a hiss, suggesting predatory and ancient.
    
- Ka: Short, and sharp in many fantasy and real world languages. A syllable meaning “land, place, or home”. 
