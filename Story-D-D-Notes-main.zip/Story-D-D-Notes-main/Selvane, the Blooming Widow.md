[[Lesser Gods]] 
**Domains:** Love, Loss, Renewal, Seasons  

**Personality:** Gentle and melancholic, yet finds beauty in grief’s transformation.  

**Symbol:** A blooming rose growing from a skull.  

**Worshippers:** Widows, gardeners, poets, lovers in mourning.  

**Rivalries:** Sythira (argues death should be final, not cyclical).  

**Quote:** “Love does not end—it changes.”

