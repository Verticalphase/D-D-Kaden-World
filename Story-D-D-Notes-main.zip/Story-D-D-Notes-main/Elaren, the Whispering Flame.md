Domains: Inspiration, Art, Passion, Chaos

Personality: Flickering, unpredictable—guides artists and rebels alike.

Symbols: A torch with a mouth-shaped flame.

Worshippers: Poets, revolutionaries, inventors, lovers.

Rivalries: Aeltherion, Sythira (who dislikes her unpredictability).

"All creation begins with a spark—or a scream."