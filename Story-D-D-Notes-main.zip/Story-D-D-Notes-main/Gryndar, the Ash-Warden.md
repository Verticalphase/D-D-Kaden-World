[[Lesser Gods]] 
**Domains:** Death, Judgment, Endurance, Purification  

**Personality:** Stern but fair, treats death as the great equalizer.  

**Symbol:** A pair of scales balanced over a pile of ash.  

**Worshippers:** Judges, undertakers, inquisitors.

**Rivalries:** Azrakar (for destruction without order).  

**Quote:** “Ashes speak the truth of all things.”

