Theme- Hidden/growing threats

                                    Tone- Mysterious and Tense.

                                     Important Events- 

- The Veil between worlds is thinning.
    
- Prophets speak of a returning god.
    
- A comet returns after 777 years, causing a great influx of magic, and potential of good/bad events to unfold. As well as prophetic nightmares.
