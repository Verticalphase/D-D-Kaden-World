[[Lesser Gods]]
**Domains:** Home, Secrets, Protection, Hospitality  

**Personality:** Warm, motherly, but fiercely protective; keeps the “fires” of safety lit for those in need. 

**Symbol:** A small flame cupped in two hands.  

**Worshippers:** Innkeepers, shelter-runners, fugitives, hidden communities.  

**Rivalries:** Arixael (tempts her wards into darkness).  

**Quote:** “Not all walls are made of stone.”
